(function ($) {
	
	"use strict";

	$(function() {
        $("#tabs").tabs();
    });
	
	$('.counter-count-number').each(function () {
        $(this).prop('Counter',0).animate({
            Counter: $(this).text()
        }, {
          
          //chnage count up speed here
            duration: 4000,
            easing: 'swing',
            step: function (now) {
                $(this).text(Math.ceil(now));
            }
        });
    });

	


	

	


})(window.jQuery);